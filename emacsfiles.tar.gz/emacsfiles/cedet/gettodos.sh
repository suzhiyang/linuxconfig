#!/bin/sh

grep -ni "@todo" `find . -name "*.el"`